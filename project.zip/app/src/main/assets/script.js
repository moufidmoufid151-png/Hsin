/* ===== الحالة والتخزين ===== */
const KEY='hisn_state_v2';
const DEF={welcomed:false,mode:'normal',since:Date.now(),streak:0,last:'',best:0,theme:'dark',url:'',pinHash:'',vibe:true,guard:false};
let S={...DEF};
try{const r=localStorage.getItem(KEY);if(r)S={...DEF,...JSON.parse(r)}}catch(e){}
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
const $=id=>document.getElementById(id);
const today=()=>{const d=new Date();return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()};
const dayDiff=(a,b)=>Math.round((new Date(b)-new Date(a))/864e5);
const hash=s=>{let h=5381;for(const c of s)h=((h<<5)+h+c.charCodeAt(0))>>>0;return String(h)};
function buzz(ms=15){if(S.vibe&&navigator.vibrate)navigator.vibrate(ms)}
let toastT;function toast(t){const e=$('toast');e.textContent=t;e.classList.add('show');clearTimeout(toastT);toastT=setTimeout(()=>e.classList.remove('show'),2400)}

/* ===== الترحيب ===== */
let wStep=0;
function nextWelcome(){
  const sl=document.querySelectorAll('.slide');
  if(wStep>=sl.length-1)return finishWelcome();
  sl[wStep].classList.remove('show');wStep++;sl[wStep].classList.add('show');
  document.querySelectorAll('#welcomeDots i').forEach((d,i)=>d.classList.toggle('on',i===wStep));
  if(wStep===sl.length-1)$('welcomeNext').textContent='ابدأ رحلة الحماية';
  buzz();
}
function finishWelcome(){
  S.welcomed=true;S.since=Date.now();if(!S.last)S.last='';save();
  $('welcomeScreen').classList.remove('active');$('mainApp').classList.remove('hidden');
  renderAll();
  if(Native)openSubSection('permSection');
}

/* ===== التبويبات ===== */
let prevTab='home';
function switchTab(t){
  document.querySelectorAll('.tab-content').forEach(e=>e.classList.remove('active'));
  const map={home:'tabHome',streak:'tabStreak',settings:'tabSettings',sub:'tabSubSection'};
  $(map[t]).classList.add('active');
  ['Home','Streak','Settings'].forEach(n=>$('nav'+n).classList.toggle('active',n.toLowerCase()===t));
  if(t!=='sub')prevTab=t;
  if(t==='streak')renderStreak();
  buzz(8);
}
function goBack(){switchTab(prevTab)}

/* ===== وضع الحماية ===== */
const MODES={
  off:{i:'🔓',t:'الحماية متوقفة',d:'أنت معرّض الآن. نوصي بتفعيلها',p:0,idx:0},
  normal:{i:'🛡️',t:'الحماية نشطة',d:'التطبيق يعمل بكفاءة عالية',p:.5,idx:1},
  strict:{i:'🏰',t:'الحماية المشدّدة',d:'أعلى مستوى حماية وحراسة',p:1,idx:2}
};
function changeMode(m,verified){
  if(m===S.mode)return;
  const lowering=MODES[m].p<MODES[S.mode].p;
  if(lowering&&S.pinHash&&!verified)return askPin(()=>changeMode(m,true),'تخفيض مستوى الحماية يحتاج رمز صديقك.');
  S.mode=m;save();renderMode(true);buzz(25);
  toast(m==='off'?'تم إيقاف الحماية':m==='strict'?'تم تفعيل الحماية المشدّدة':'تم تفعيل الحماية المتوسطة');
}
function renderMode(anim){
  const M=MODES[S.mode];
  $('statusShieldIcon').textContent=M.i;$('statusTitle').textContent=M.t;$('statusDesc').textContent=M.d;
  $('statusCard').dataset.mode=S.mode;
  $('ring').style.strokeDashoffset=364.4*(1-M.p);
  $('ring').style.stroke=S.mode==='strict'?'var(--warn)':S.mode==='off'?'var(--danger)':'var(--accent)';
  $('modePill').style.background=S.mode==='strict'?'var(--warn)':S.mode==='off'?'var(--danger)':'var(--accent)';
  // RTL: الانزياح يكون بالاتجاه السالب
  $('modePill').style.transform=`translateX(${-100*M.idx}%)`;
  ['Off','Normal','Strict'].forEach(n=>$('btn'+n).classList.toggle('active',n.toLowerCase()===S.mode));
  if(anim){const e=$('statusShieldIcon');e.classList.remove('bump');void e.offsetWidth;e.classList.add('bump')}
  tickUptime();
}
function tickUptime(){
  if(S.mode==='off'){$('uptime').textContent='';return}
  const s=Math.floor((Date.now()-S.since)/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60);
  $('uptime').textContent=`محميّ منذ ${d?d+' يوم ':''}${h} ساعة ${m} دقيقة`;
}
setInterval(tickUptime,30000);

/* ===== الاستريك ===== */
const GOALS=[1,3,7,14,30,60,90];
const BADGES=[[1,'🌱','يوم'],[3,'🔥','3 أيام'],[7,'⭐','أسبوع'],[14,'💎','أسبوعان'],[30,'🏆','شهر'],[90,'👑','90 يوم']];
function liveStreak(){ // يُصفّر تلقائياً إذا فاتك يوم كامل
  if(S.last&&dayDiff(S.last,today())>1){S.streak=0;save()}
  return S.streak;
}
function checkIn(){
  if(S.last===today())return toast('سجّلت يومك بالفعل. أحسنت 👏');
  S.streak=(S.last&&dayDiff(S.last,today())===1)?S.streak+1:1;
  S.last=today();S.best=Math.max(S.best,S.streak);save();
  buzz([20,40,20]);renderStreak(true);
  const g=GOALS.includes(S.streak);
  toast(g?`🎉 إنجاز جديد: ${S.streak} يوم متتالي!`:`أحسنت! ${S.streak} يوم متتالي`);
}
function resetStreak(){
  const go=()=>{S.streak=0;S.last='';save();renderStreak();toast('لا بأس. البداية الجديدة قوة 💪')};
  if(S.pinHash)askPin(go,'إعادة العدّاد تحتاج رمز صديقك.');
  else if(confirm('هل تريد إعادة العدّاد من جديد؟'))go();
}
function renderStreak(pop){
  const n=liveStreak(),goal=GOALS.find(g=>g>n)||GOALS[GOALS.length-1];
  $('streakCount').textContent=n;
  $('streakMsg').textContent=n?`أفضل رقم لك: ${S.best} يوم`:'ابدأ أول يوم بالضغط على الزر أدناه';
  const cells=goal>14?14:goal; // شبكة مرئية مختصرة
  const filled=goal>14?Math.min(14,Math.round(n/goal*14)):n;
  $('streakDots').innerHTML=Array.from({length:cells},(_,i)=>`<div class="dot ${i<filled?'done':''} ${pop&&i===filled-1?'pop':''}">${i<filled?'✓':i+1}</div>`).join('');
  $('nextGoal').textContent=n>=GOALS[GOALS.length-1]?'وصلت لأعلى هدف. استمر!':`الهدف القادم: ${goal} يوم (باقي ${goal-n})`;
  $('badges').innerHTML=BADGES.map(b=>`<div class="badge ${S.best>=b[0]?'got':''}"><span>${b[1]}</span>${b[2]}</div>`).join('');
  const done=S.last===today();const bt=$('checkinBtn');
  bt.textContent=done?'✔ تم تسجيل اليوم':'✅ سجّلت يومي اليوم';bt.style.opacity=done?.55:1;
}

/* ===== الأقسام الفرعية ===== */
const SUBS={
  permSection:{t:'الأذونات ومانع الحذف',h:()=>{
    if(!Native)return '<p class="hint">هذه الأذونات تعمل فقط داخل تطبيق الأندرويد (APK). ستظهر هنا بعد التحويل.</p>';
    const row=(ok,t,d,fn)=>`<div class="perm-row"><div><b>${t}</b><small>${d}</small></div>${ok?'<span class="perm-ok">✔ مفعّل</span>':`<button class="perm-btn" onclick="${fn}()">تفعيل</button>`}</div>`;
    const all=perms.overlay&&perms.admin&&perms.accessibility;
    return row(perms.overlay,'الظهور فوق التطبيقات','لعرض رسالة المنع فوق أي شاشة','reqOverlay')
      +row(perms.admin,'مسؤول الجهاز','يمنع حذف التطبيق بالطريقة العادية','reqAdmin')
      +row(perms.accessibility,'خدمة إمكانية الوصول','تكتشف محاولة الحذف وتعرض الرسالة','reqAcc')
      +`<div class="perm-row"><div><b>🔒 مانع الحذف</b><small>${all?'جاهز للتفعيل':'فعّل الأذونات الثلاثة أولاً'}</small></div><button class="perm-btn ${S.guard&&all?'on':''}" onclick="toggleGuard()">${S.guard&&all?'إيقاف':'تشغيل'}</button></div>`
      +(S.pinHash?'<p class="hint" style="margin-top:10px">إيقاف المانع يحتاج رمز صديقك.</p>':'<p class="hint" style="margin-top:10px">نوصي بتفعيل حماية الصديق ليحتاج إيقاف المانع رمزاً.</p>');
  }},
  customUrlSection:{t:'تخصيص شاشة الرصد',h:()=>`
    <p class="hint">عند محاولة فتح موقع محظور، يُحوّلك التطبيق إلى هذا الرابط (مثل مقال أو دعاء أو هدفك).</p>
    <input class="field" id="urlInput" type="url" placeholder="https://example.com" value="${S.url}">
    <div class="msg" id="urlMsg"></div>
    <button class="btn primary-btn" onclick="saveUrl()">حفظ الرابط</button>`},
  friendSection:{t:'حماية الصديق',h:()=>S.pinHash?`
    <p class="hint">✅ حماية الصديق مفعّلة. تخفيض الحماية وإعادة العدّاد يحتاجان رمزه.</p>
    <button class="btn danger-btn" style="margin-top:14px" onclick="disableFriend()">إلغاء حماية الصديق</button>`:`
    <p class="hint">اطلب من شخص تثق به أن يكتب رمزاً (4 أرقام أو أكثر) دون أن تراه. لن تستطيع تخفيف الحماية بدونه.</p>
    <input class="field" id="newPin" type="password" inputmode="numeric" placeholder="رمز الصديق">
    <input class="field" id="newPin2" type="password" inputmode="numeric" placeholder="أعد كتابة الرمز">
    <div class="msg" id="pinMsg"></div>
    <button class="btn primary-btn" onclick="saveFriendPin()">تفعيل</button>`},
  vibeSection:{t:'الاهتزاز',h:()=>`<p class="hint">اهتزاز خفيف عند الأزرار والإنجازات.</p>
    <button class="btn primary-btn" style="margin-top:14px" onclick="toggleVibe()">${S.vibe?'إيقاف الاهتزاز':'تفعيل الاهتزاز'}</button>`}
};
function openSubSection(id){
  const s=SUBS[id];$('subTitle').textContent=s.t;curSub=id;$('subContentArea').innerHTML=s.h();switchTab('sub');if(id==='permSection')refreshPerms();
}
function saveUrl(){
  const v=$('urlInput').value.trim(),m=$('urlMsg');
  if(v&&!/^https?:\/\/[^\s.]+\.[^\s]+$/i.test(v)){m.className='msg err';m.textContent='الرابط غير صحيح. ابدأه بـ https://';return}
  S.url=v;save();m.className='msg ok';m.textContent=v?'تم حفظ الرابط ✔':'تمت إزالة الرابط المخصّص';buzz();
}
function saveFriendPin(){
  const a=$('newPin').value,b=$('newPin2').value,m=$('pinMsg');m.className='msg err';
  if(a.length<4)return m.textContent='الرمز لا يقل عن 4 أرقام';
  if(a!==b)return m.textContent='الرمزان غير متطابقين';
  S.pinHash=hash(a);save();toast('تم تفعيل حماية الصديق 🤝');openSubSection('friendSection');
}
function disableFriend(){askPin(()=>{S.pinHash='';save();toast('تم إلغاء حماية الصديق');openSubSection('friendSection')},'أدخل رمز الصديق لإلغاء الحماية.')}
function toggleVibe(){S.vibe=!S.vibe;save();$('vibeState').textContent=S.vibe?'مفعّل':'متوقف';openSubSection('vibeSection')}

/* ===== نافذة الرمز ===== */
let pinCb=null;
function askPin(cb,reason){pinCb=cb;$('pinReason').textContent=reason||'أدخل الرمز للمتابعة:';$('modalPinInput').value='';$('pinErr').textContent='';$('pinModal').classList.remove('hidden');setTimeout(()=>$('modalPinInput').focus(),50)}
function verifyPinAction(){
  if(hash($('modalPinInput').value)===S.pinHash){const cb=pinCb;closePinModal();cb&&cb()}
  else{$('pinErr').textContent='الرمز غير صحيح';buzz([40,30,40])}
}
function closePinModal(){$('pinModal').classList.add('hidden');pinCb=null}

/* ===== تمرين التنفس (4-4-6) ===== */
const QUOTES=['الرغبة موجة، وتزول إذا لم تتبعها.','أنت أقوى من لحظة ضعف عابرة.','غيّر مكانك الآن: قم، اغسل وجهك، وتحرّك.','تذكّر لماذا بدأت، وما الذي تحميه.'];
let bTimer,bRun=false;
function openBreathing(){
  $('breathing').classList.remove('hidden');bRun=true;buzz(20);
  $('breathMsg').textContent=QUOTES[Math.floor(Math.random()*QUOTES.length)];
  const o=$('orb');
  const cycle=()=>{
    if(!bRun)return;
    o.className='orb in';o.textContent='شهيق';
    bTimer=setTimeout(()=>{if(!bRun)return;o.className='orb hold';o.textContent='ثبّت';
      bTimer=setTimeout(()=>{if(!bRun)return;o.className='orb out';o.textContent='زفير';bTimer=setTimeout(cycle,6000)},4000)},4000);
  };
  setTimeout(cycle,50);
}
function closeBreathing(){bRun=false;clearTimeout(bTimer);$('breathing').classList.add('hidden');toast('أحسنت. اخترت الأقوى 💚')}

/* ===== المظهر ===== */
function toggleTheme(){S.theme=S.theme==='dark'?'light':'dark';save();applyTheme();buzz()}
function applyTheme(){
  document.body.className=S.theme==='dark'?'dark-theme':'light-theme';
  $('themeBtn').textContent=S.theme==='dark'?'☀️ ساطع':'🌙 ليلي';
}

/* ===== جسر الأندرويد: الأذونات ومانع الحذف ===== */
const B=window.AndroidBridge;
const Native=B?{
  getStatus:async()=>JSON.parse(B.getStatus()),
  requestOverlay:async()=>B.requestOverlay(),
  requestAdmin:async()=>B.requestAdmin(),
  openAccessibility:async()=>B.openAccessibility(),
  setGuard:async o=>B.setGuard(!!o.enabled),
  removeAdmin:async()=>B.removeAdmin()
}:null;
let perms={overlay:false,admin:false,accessibility:false},curSub='';
async function refreshPerms(){
  if(!Native)return;
  try{perms=await Native.getStatus();
    const all=perms.overlay&&perms.admin&&perms.accessibility;
    await Native.setGuard({enabled:!!(S.guard&&all)});}catch(e){}
  if(curSub==='permSection'&&$('tabSubSection').classList.contains('active'))$('subContentArea').innerHTML=SUBS.permSection.h();
}
function reqOverlay(){Native.requestOverlay()}
function reqAdmin(){Native.requestAdmin()}
function reqAcc(){toast('ابحث عن «حصن النفس» ثم فعّله');Native.openAccessibility()}
function toggleGuard(){
  if(!S.guard){
    if(!(perms.overlay&&perms.admin&&perms.accessibility))return toast('فعّل الأذونات الثلاثة أولاً');
    S.guard=true;save();buzz([20,40,20]);toast('تم تفعيل مانع الحذف 🔒');refreshPerms();
  }else{
    const off=()=>{S.guard=false;save();Native.setGuard({enabled:false});Native.removeAdmin();toast('تم إيقاف مانع الحذف');refreshPerms()};
    S.pinHash?askPin(off,'إيقاف مانع الحذف يحتاج رمز صديقك.'):off();
  }
}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshPerms()});
window.addEventListener('focus',refreshPerms);

/* ===== التشغيل ===== */
function renderAll(){applyTheme();renderMode();renderStreak();$('vibeState').textContent=S.vibe?'مفعّل':'متوقف'}
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&!$('pinModal').classList.contains('hidden'))verifyPinAction()});
applyTheme();
if(S.welcomed){$('welcomeScreen').classList.remove('active');$('mainApp').classList.remove('hidden');renderAll()}

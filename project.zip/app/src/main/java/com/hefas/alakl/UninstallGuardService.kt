package com.hefas.alakl

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView

class UninstallGuardService : AccessibilityService() {

    private var lastBlock = 0L
    // يُقرأ تلقائياً من اسم التطبيق على الجهاز (app_name)
    private val appName by lazy { applicationInfo.loadLabel(packageManager).toString() }
    private val watched = setOf(
        "com.android.settings", "com.google.android.packageinstaller",
        "com.android.packageinstaller", "com.miui.packageinstaller", "com.miui.securitycenter"
    )
    private val keywords = listOf(
        "إلغاء التثبيت", "حذف", "Uninstall", "Delete",
        "إلغاء تنشيط", "Deactivate", "مسؤول الجهاز", "Device admin"
    )

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (pkg == packageName || pkg !in watched) return
        if (!getSharedPreferences("hisn", MODE_PRIVATE).getBoolean("guard", false)) return
        val root = rootInActiveWindow ?: return
        val sb = StringBuilder(); collect(root, sb)
        val t = sb.toString()
        if (t.contains(appName) && keywords.any { t.contains(it, ignoreCase = true) }) block()
    }

    private fun collect(n: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (n == null) return
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until n.childCount) collect(n.getChild(i), sb)
    }

    private fun block() {
        val now = System.currentTimeMillis()
        if (now - lastBlock < 3000) return
        lastBlock = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        showOverlay()
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = "🛡️\n\nلا يمكنك حذف $appName الآن\nتذكّر لماذا بدأت"
            setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER
            setBackgroundColor(0xF00B1A20.toInt()); setPadding(60, 60, 60, 60)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(tv, lp)
        Handler(Looper.getMainLooper()).postDelayed({ runCatching { wm.removeView(tv) } }, 3500)
    }

    override fun onInterrupt() {}
}

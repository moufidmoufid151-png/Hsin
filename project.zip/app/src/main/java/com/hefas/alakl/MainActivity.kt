package com.hefas.alakl

import android.accessibilityservice.AccessibilityServiceInfo
import android.annotation.SuppressLint
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        web.setBackgroundColor(0xFF0B1A20.toInt())
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { moveTaskToBack(true) }
        })
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("if(window.refreshPerms)refreshPerms()", null)
    }

    inner class Bridge {
        private fun admin() = ComponentName(this@MainActivity, HisnAdminReceiver::class.java)
        private fun dpm() = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

        @JavascriptInterface
        fun getStatus(): String {
            val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            val acc = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
                .any { it.resolveInfo.serviceInfo.packageName == packageName }
            return JSONObject()
                .put("overlay", Settings.canDrawOverlays(this@MainActivity))
                .put("admin", dpm().isAdminActive(admin()))
                .put("accessibility", acc)
                .toString()
        }

        @JavascriptInterface
        fun requestOverlay() = runOnUiThread {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        @JavascriptInterface
        fun requestAdmin() = runOnUiThread {
            startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin())
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "تفعيل هذا الإذن يمنع حذف حصن النفس بسهولة ويحميك من القرارات اللحظية.")
            )
        }

        @JavascriptInterface
        fun openAccessibility() = runOnUiThread {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        @JavascriptInterface
        fun setGuard(enabled: Boolean) {
            getSharedPreferences("hisn", Context.MODE_PRIVATE).edit().putBoolean("guard", enabled).apply()
        }

        @JavascriptInterface
        fun removeAdmin() {
            if (dpm().isAdminActive(admin())) dpm().removeActiveAdmin(admin())
        }
    }
}

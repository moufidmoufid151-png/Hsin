package com.hefas.alakl

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class HisnAdminReceiver : DeviceAdminReceiver() {
    // تظهر هذه الرسالة عندما يحاول المستخدم تعطيل صلاحية مسؤول الجهاز
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "⚠️ تعطيل هذه الصلاحية سيسمح بحذف حصن النفس. هل أنت متأكد أنك تريد التراجع عن حمايتك؟"
}
